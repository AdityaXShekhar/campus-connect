const { User } = require("../models");

/** Attaches req.user from session (if logged in) on every request. */
async function loadUser(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = await User.findByPk(req.session.userId);
      if (user && !user.isSuspended) {
        req.user = user;
      } else {
        req.session.userId = null;
      }
    } catch (e) {
      req.user = null;
    }
  }
  res.locals.currentUser = req.user || null;
  next();
}

function wantsJson(req) {
  return req.originalUrl.startsWith("/api/");
}

function loginRequired(req, res, next) {
  if (!req.user) {
    if (wantsJson(req)) return res.status(401).json({ error: "Authentication required." });
    return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
  }
  next();
}

function adminRequired(req, res, next) {
  if (!req.user) {
    if (wantsJson(req)) return res.status(401).json({ error: "Authentication required." });
    return res.redirect("/login");
  }
  if (req.user.role !== "admin") {
    if (wantsJson(req)) return res.status(403).json({ error: "Admin access required." });
    return res.status(403).render("errors/403");
  }
  next();
}

function verifiedRequired(req, res, next) {
  if (!req.user) return res.status(401).json({ error: "Authentication required." });
  if (!req.user.isVerified) {
    return res.status(403).json({ error: "Please verify your university email first." });
  }
  next();
}

module.exports = { loadUser, loginRequired, adminRequired, verifiedRequired };
