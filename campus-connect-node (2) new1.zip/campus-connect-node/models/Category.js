const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Category = sequelize.define("Category", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING(80), allowNull: false, unique: true },
  icon: { type: DataTypes.STRING(50), defaultValue: "tag" },
}, {
  tableName: "categories",
  underscored: true,
  timestamps: false,
});

module.exports = Category;
