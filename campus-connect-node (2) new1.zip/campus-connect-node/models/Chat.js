const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Conversation = sequelize.define("Conversation", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  listingId: { type: DataTypes.INTEGER, allowNull: false, field: "listing_id" },
  user1Id: { type: DataTypes.INTEGER, allowNull: false, field: "user1_id" },
  user2Id: { type: DataTypes.INTEGER, allowNull: false, field: "user2_id" },
}, {
  tableName: "conversations",
  underscored: true,
  timestamps: true,
  updatedAt: false,
  indexes: [{ unique: true, fields: ["listing_id", "user1_id", "user2_id"] }],
});

const Message = sequelize.define("Message", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  conversationId: { type: DataTypes.INTEGER, allowNull: false, field: "conversation_id" },
  senderId: { type: DataTypes.INTEGER, allowNull: false, field: "sender_id" },
  message: { type: DataTypes.TEXT, allowNull: false },
  isRead: { type: DataTypes.BOOLEAN, defaultValue: false, field: "is_read" },
}, {
  tableName: "messages",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

Conversation.prototype.otherUserId = function (currentUserId) {
  return this.user1Id === currentUserId ? this.user2Id : this.user1Id;
};

module.exports = { Conversation, Message };
