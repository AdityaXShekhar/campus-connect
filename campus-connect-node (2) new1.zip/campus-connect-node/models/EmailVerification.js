const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const EmailVerification = sequelize.define("EmailVerification", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: "user_id" },
  otpCode: { type: DataTypes.STRING(10), allowNull: false, field: "otp_code" },
  isUsed: { type: DataTypes.BOOLEAN, defaultValue: false, field: "is_used" },
  expiresAt: { type: DataTypes.DATE, allowNull: false, field: "expires_at" },
}, {
  tableName: "email_verifications",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

module.exports = EmailVerification;
