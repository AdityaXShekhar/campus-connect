const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const ErrandRequest = sequelize.define("ErrandRequest", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  requesterId: { type: DataTypes.INTEGER, allowNull: false, field: "requester_id" },
  title: { type: DataTypes.STRING(150), allowNull: false },
  description: { type: DataTypes.TEXT },
  pickupLocation: { type: DataTypes.STRING(150), allowNull: false, field: "pickup_location" },
  destination: { type: DataTypes.STRING(150), allowNull: false },
  date: { type: DataTypes.DATEONLY, allowNull: false },
  reward: { type: DataTypes.STRING(80) },
  status: { type: DataTypes.STRING(20), defaultValue: "open" }, // open, accepted, completed, cancelled
  acceptedBy: { type: DataTypes.INTEGER, field: "accepted_by" },
}, {
  tableName: "errand_requests",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

ErrandRequest.prototype.toDict = function () {
  return {
    id: this.id,
    title: this.title,
    description: this.description,
    pickup_location: this.pickupLocation,
    destination: this.destination,
    date: this.date,
    reward: this.reward,
    status: this.status,
    requester: this.requester ? this.requester.toPublicDict() : null,
    helper: this.helper ? this.helper.toPublicDict() : null,
    created_at: new Date(this.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
  };
};

module.exports = ErrandRequest;
