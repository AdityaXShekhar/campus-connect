const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Event = sequelize.define("Event", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  title: { type: DataTypes.STRING(150), allowNull: false },
  description: { type: DataTypes.TEXT },
  category: { type: DataTypes.STRING(40), defaultValue: "Campus Fest" },
  date: { type: DataTypes.DATEONLY, allowNull: false },
  time: { type: DataTypes.STRING(20) },
  location: { type: DataTypes.STRING(150) },
  organizer: { type: DataTypes.STRING(120) },
  image: { type: DataTypes.STRING(255) },
  createdBy: { type: DataTypes.INTEGER, field: "created_by" },
}, {
  tableName: "events",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

Event.prototype.toDict = function () {
  return {
    id: this.id,
    title: this.title,
    description: this.description,
    category: this.category,
    date: this.date,
    date_display: new Date(this.date + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
    time: this.time,
    location: this.location,
    organizer: this.organizer,
    image: this.image,
  };
};

module.exports = Event;
