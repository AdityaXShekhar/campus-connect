const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Listing = sequelize.define("Listing", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  sellerId: { type: DataTypes.INTEGER, allowNull: false, field: "seller_id" },
  title: { type: DataTypes.STRING(150), allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: false },
  categoryId: { type: DataTypes.INTEGER, allowNull: false, field: "category_id" },
  transactionType: { type: DataTypes.STRING(20), allowNull: false, field: "transaction_type" }, // sell, rent, exchange, buy
  price: { type: DataTypes.FLOAT, allowNull: false, defaultValue: 0 },
  condition: { type: DataTypes.STRING(30), allowNull: false, defaultValue: "Good" },
  location: { type: DataTypes.STRING(150) },
  status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: "active" }, // active, reserved, completed, removed
  availableFrom: { type: DataTypes.DATEONLY, field: "available_from" },
  availableUntil: { type: DataTypes.DATEONLY, field: "available_until" },
  exchangePreference: { type: DataTypes.STRING(255), field: "exchange_preference" },
  views: { type: DataTypes.INTEGER, defaultValue: 0 },
}, {
  tableName: "listings",
  underscored: true,
  timestamps: true,
  
});

const ListingImage = sequelize.define("ListingImage", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  listingId: { type: DataTypes.INTEGER, allowNull: false, field: "listing_id" },
  imagePath: { type: DataTypes.STRING(255), allowNull: false, field: "image_path" },
}, {
  tableName: "listing_images",
  underscored: true,
  timestamps: false,
});

Listing.prototype.primaryImage = function () {
  if (this.images && this.images.length) return this.images[0].imagePath;
  return null;
};

Listing.prototype.toCardDict = function () {
  return {
    id: this.id,
    title: this.title,
    price: this.price,
    category: this.category ? this.category.name : null,
    condition: this.condition,
    transaction_type: this.transactionType,
    seller_name: this.seller ? this.seller.name : null,
    seller_verified: this.seller ? this.seller.isVerified : false,
    location: this.location,
    status: this.status,
    created_at: this.createdAt
      ? new Date(this.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" })
      : null,
    image: this.primaryImage(),
  };
};

Listing.prototype.toDetailDict = function () {
  const d = this.toCardDict();
  return {
    ...d,
    description: this.description,
    available_from: this.availableFrom,
    available_until: this.availableUntil,
    exchange_preference: this.exchangePreference,
    images: (this.images || []).map((img) => img.imagePath),
    seller: this.seller ? this.seller.toPublicDict() : null,
  };
};

module.exports = { Listing, ListingImage };
