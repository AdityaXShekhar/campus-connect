const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Notification = sequelize.define("Notification", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: "user_id" },
  title: { type: DataTypes.STRING(150), allowNull: false },
  message: { type: DataTypes.STRING(255), allowNull: false },
  type: { type: DataTypes.STRING(30), defaultValue: "general" },
  link: { type: DataTypes.STRING(255) },
  isRead: { type: DataTypes.BOOLEAN, defaultValue: false, field: "is_read" },
}, {
  tableName: "notifications",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

Notification.prototype.toDict = function () {
  return {
    id: this.id,
    title: this.title,
    message: this.message,
    type: this.type,
    link: this.link,
    is_read: this.isRead,
    created_at: new Date(this.createdAt).toLocaleString("en-US", {
      month: "short", day: "2-digit", hour: "numeric", minute: "2-digit", hour12: true,
    }),
  };
};

/** Helper used across routes to create a notification row (call .save()/await create separately). */
async function pushNotification(userId, title, message, type = "general", link = null) {
  return Notification.create({ userId, title, message, type, link });
}

module.exports = { Notification, pushNotification };
