const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Report = sequelize.define("Report", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  reporterId: { type: DataTypes.INTEGER, allowNull: false, field: "reporter_id" },
  listingId: { type: DataTypes.INTEGER, field: "listing_id" },
  reportedUserId: { type: DataTypes.INTEGER, field: "reported_user_id" },
  reason: { type: DataTypes.STRING(50), allowNull: false },
  description: { type: DataTypes.TEXT },
  status: { type: DataTypes.STRING(20), defaultValue: "pending" }, // pending, reviewed, resolved, dismissed
}, {
  tableName: "reports",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

module.exports = Report;
