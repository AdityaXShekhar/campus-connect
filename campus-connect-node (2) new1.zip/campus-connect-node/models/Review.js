const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Review = sequelize.define("Review", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  transactionId: { type: DataTypes.INTEGER, allowNull: false, field: "transaction_id" },
  reviewerId: { type: DataTypes.INTEGER, allowNull: false, field: "reviewer_id" },
  reviewedUserId: { type: DataTypes.INTEGER, allowNull: false, field: "reviewed_user_id" },
  rating: { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1, max: 5 } },
  comment: { type: DataTypes.TEXT },
}, {
  tableName: "reviews",
  underscored: true,
  timestamps: true,
  updatedAt: false,
  indexes: [{ unique: true, fields: ["transaction_id", "reviewer_id"] }],
});

module.exports = Review;
