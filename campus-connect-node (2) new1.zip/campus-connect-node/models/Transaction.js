const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Transaction = sequelize.define("Transaction", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  listingId: { type: DataTypes.INTEGER, allowNull: false, field: "listing_id" },
  buyerId: { type: DataTypes.INTEGER, allowNull: false, field: "buyer_id" },
  sellerId: { type: DataTypes.INTEGER, allowNull: false, field: "seller_id" },
  transactionType: { type: DataTypes.STRING(20), allowNull: false, field: "transaction_type" },
  status: { type: DataTypes.STRING(20), allowNull: false, defaultValue: "pending" },
  // pending, accepted, rejected, completed, cancelled
  rentalStart: { type: DataTypes.DATEONLY, field: "rental_start" },
  rentalEnd: { type: DataTypes.DATEONLY, field: "rental_end" },
  exchangeOffer: { type: DataTypes.STRING(255), field: "exchange_offer" },
  buyerConfirmed: { type: DataTypes.BOOLEAN, defaultValue: false, field: "buyer_confirmed" },
  sellerConfirmed: { type: DataTypes.BOOLEAN, defaultValue: false, field: "seller_confirmed" },
  completedAt: { type: DataTypes.DATE, field: "completed_at" },
}, {
  tableName: "transactions",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

Transaction.prototype.toDict = function () {
  return {
    id: this.id,
    listing: this.listing ? this.listing.toCardDict() : null,
    buyer: this.buyer ? this.buyer.toPublicDict() : null,
    seller: this.seller ? this.seller.toPublicDict() : null,
    transaction_type: this.transactionType,
    status: this.status,
    rental_start: this.rentalStart,
    rental_end: this.rentalEnd,
    exchange_offer: this.exchangeOffer,
    buyer_confirmed: this.buyerConfirmed,
    seller_confirmed: this.sellerConfirmed,
    created_at: new Date(this.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
  };
};

module.exports = Transaction;
