const { DataTypes } = require("sequelize");
const bcrypt = require("bcryptjs");
const sequelize = require("./db");

const User = sequelize.define("User", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING(120), allowNull: false },
  email: { type: DataTypes.STRING(160), allowNull: false, unique: true },
  passwordHash: { type: DataTypes.STRING(255), allowNull: false, field: "password_hash" },
  role: { type: DataTypes.STRING(20), allowNull: false, defaultValue: "student" }, // student, faculty, staff, admin
  department: { type: DataTypes.STRING(120) },
  phone: { type: DataTypes.STRING(20) },
  profileImage: { type: DataTypes.STRING(255), defaultValue: "default_avatar.png", field: "profile_image" },
  bio: { type: DataTypes.TEXT },
  isVerified: { type: DataTypes.BOOLEAN, defaultValue: false, field: "is_verified" },
  isSuspended: { type: DataTypes.BOOLEAN, defaultValue: false, field: "is_suspended" },
  rating: { type: DataTypes.FLOAT, defaultValue: 0 },
  ratingCount: { type: DataTypes.INTEGER, defaultValue: 0, field: "rating_count" },
}, {
  tableName: "users",
  underscored: true,
  timestamps: true,
  updatedAt: false,
});

User.prototype.setPassword = function (rawPassword) {
  this.passwordHash = bcrypt.hashSync(rawPassword, 10);
};

User.prototype.checkPassword = function (rawPassword) {
  return bcrypt.compareSync(rawPassword, this.passwordHash);
};

User.prototype.toPublicDict = function () {
  return {
    id: this.id,
    name: this.name,
    role: this.role,
    department: this.department,
    profile_image: this.profileImage,
    is_verified: this.isVerified,
    rating: Math.round((this.rating || 0) * 10) / 10,
    rating_count: this.ratingCount,
    bio: this.bio,
    member_since: this.createdAt
      ? new Date(this.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })
      : null,
  };
};

User.prototype.toDict = function () {
  return { ...this.toPublicDict(), email: this.email, phone: this.phone };
};

module.exports = User;
