const { DataTypes } = require("sequelize");
const sequelize = require("./db");

const Wishlist = sequelize.define("Wishlist", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: "user_id" },
  listingId: { type: DataTypes.INTEGER, allowNull: false, field: "listing_id" },
}, {
  tableName: "wishlist",
  underscored: true,
  timestamps: true,
  updatedAt: false,
  indexes: [{ unique: true, fields: ["user_id", "listing_id"] }],
});

module.exports = Wishlist;
