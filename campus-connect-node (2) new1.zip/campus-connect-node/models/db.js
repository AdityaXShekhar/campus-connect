const { Sequelize } = require("sequelize");
const fs = require("fs");
const path = require("path");
const config = require("../config");

let sequelize;

if (config.dbDialect === "mysql") {
  sequelize = new Sequelize(config.dbName, config.dbUser, config.dbPassword, {
    host: config.dbHost,
    port: config.dbPort,
    dialect: "mysql",
    logging: false,
  });
} else {
  // SQLite — zero-config local demo database
  fs.mkdirSync(path.dirname(config.dbStorage), { recursive: true });
  sequelize = new Sequelize({
    dialect: "sqlite",
    storage: config.dbStorage,
    logging: false,
  });
}

module.exports = sequelize;
