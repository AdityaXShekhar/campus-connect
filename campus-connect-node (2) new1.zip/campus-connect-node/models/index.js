const sequelize = require("./db");
const User = require("./User");
const Category = require("./Category");
const { Listing, ListingImage } = require("./Listing");
const Wishlist = require("./Wishlist");
const { Conversation, Message } = require("./Chat");
const Transaction = require("./Transaction");
const Review = require("./Review");
const { Notification, pushNotification } = require("./Notification");
const Event = require("./Event");
const ErrandRequest = require("./ErrandRequest");
const Report = require("./Report");
const EmailVerification = require("./EmailVerification");

// ---------------------------------------------------------------------------
// Associations (mirrors the relational design in schema.sql)
// ---------------------------------------------------------------------------

// User -> Listings
User.hasMany(Listing, { foreignKey: "sellerId", as: "listings" });
Listing.belongsTo(User, { foreignKey: "sellerId", as: "seller" });

// Category -> Listings
Category.hasMany(Listing, { foreignKey: "categoryId", as: "listings" });
Listing.belongsTo(Category, { foreignKey: "categoryId", as: "category" });

// Listing -> Images
Listing.hasMany(ListingImage, { foreignKey: "listingId", as: "images", onDelete: "CASCADE" });
ListingImage.belongsTo(Listing, { foreignKey: "listingId" });

// User <-> Listing (Wishlist)
User.hasMany(Wishlist, { foreignKey: "userId", as: "wishlistItems", onDelete: "CASCADE" });
Wishlist.belongsTo(User, { foreignKey: "userId" });
Listing.hasMany(Wishlist, { foreignKey: "listingId", as: "wishlistedBy", onDelete: "CASCADE" });
Wishlist.belongsTo(Listing, { foreignKey: "listingId", as: "listing" });

// Conversations
Listing.hasMany(Conversation, { foreignKey: "listingId", as: "conversations" });
Conversation.belongsTo(Listing, { foreignKey: "listingId", as: "listing" });
User.hasMany(Conversation, { foreignKey: "user1Id", as: "conversationsAsUser1" });
User.hasMany(Conversation, { foreignKey: "user2Id", as: "conversationsAsUser2" });
Conversation.belongsTo(User, { foreignKey: "user1Id", as: "user1" });
Conversation.belongsTo(User, { foreignKey: "user2Id", as: "user2" });

// Messages
Conversation.hasMany(Message, { foreignKey: "conversationId", as: "messages", onDelete: "CASCADE" });
Message.belongsTo(Conversation, { foreignKey: "conversationId" });
User.hasMany(Message, { foreignKey: "senderId", as: "sentMessages" });
Message.belongsTo(User, { foreignKey: "senderId", as: "sender" });

// Transactions
Listing.hasMany(Transaction, { foreignKey: "listingId", as: "transactions" });
Transaction.belongsTo(Listing, { foreignKey: "listingId", as: "listing" });
User.hasMany(Transaction, { foreignKey: "buyerId", as: "purchases" });
User.hasMany(Transaction, { foreignKey: "sellerId", as: "sales" });
Transaction.belongsTo(User, { foreignKey: "buyerId", as: "buyer" });
Transaction.belongsTo(User, { foreignKey: "sellerId", as: "seller" });

// Reviews
Transaction.hasMany(Review, { foreignKey: "transactionId", as: "reviews", onDelete: "CASCADE" });
Review.belongsTo(Transaction, { foreignKey: "transactionId" });
User.hasMany(Review, { foreignKey: "reviewerId", as: "reviewsGiven" });
User.hasMany(Review, { foreignKey: "reviewedUserId", as: "reviewsReceived" });
Review.belongsTo(User, { foreignKey: "reviewerId", as: "reviewer" });
Review.belongsTo(User, { foreignKey: "reviewedUserId", as: "reviewedUser" });

// Notifications
User.hasMany(Notification, { foreignKey: "userId", as: "notifications", onDelete: "CASCADE" });
Notification.belongsTo(User, { foreignKey: "userId" });

// Events
User.hasMany(Event, { foreignKey: "createdBy", as: "eventsCreated" });
Event.belongsTo(User, { foreignKey: "createdBy", as: "creator" });

// Errand requests
User.hasMany(ErrandRequest, { foreignKey: "requesterId", as: "errandsRequested" });
ErrandRequest.belongsTo(User, { foreignKey: "requesterId", as: "requester" });
User.hasMany(ErrandRequest, { foreignKey: "acceptedBy", as: "errandsHelped" });
ErrandRequest.belongsTo(User, { foreignKey: "acceptedBy", as: "helper" });

// Reports
User.hasMany(Report, { foreignKey: "reporterId", as: "reportsFiled" });
Report.belongsTo(User, { foreignKey: "reporterId", as: "reporter" });
User.hasMany(Report, { foreignKey: "reportedUserId", as: "reportsAgainst" });
Report.belongsTo(User, { foreignKey: "reportedUserId", as: "reportedUser" });
Listing.hasMany(Report, { foreignKey: "listingId", as: "reports" });
Report.belongsTo(Listing, { foreignKey: "listingId", as: "listing" });

// Email verification
User.hasMany(EmailVerification, { foreignKey: "userId", as: "verifications" });
EmailVerification.belongsTo(User, { foreignKey: "userId" });

module.exports = {
  sequelize,
  User,
  Category,
  Listing,
  ListingImage,
  Wishlist,
  Conversation,
  Message,
  Transaction,
  Review,
  Notification,
  pushNotification,
  Event,
  ErrandRequest,
  Report,
  EmailVerification,
};
