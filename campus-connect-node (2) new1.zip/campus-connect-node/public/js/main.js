/* Campus Connect — shared front-end utilities (vanilla JS, no build step) */

const CC = (() => {
  async function api(path, { method = "GET", body, isForm = false } = {}) {
    const opts = { method, credentials: "same-origin" };
    if (body) {
      if (isForm) {
        opts.body = body; // FormData - browser sets content-type
      } else {
        opts.headers = { "Content-Type": "application/json" };
        opts.body = JSON.stringify(body);
      }
    }
    const res = await fetch(`/api${path}`, opts);
    let data = {};
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
      const err = new Error(data.error || "Something went wrong.");
      err.status = res.status;
      err.fields = data.fields;
      throw err;
    }
    return data;
  }

  function toast(message, type = "info") {
    let stack = document.getElementById("toast-stack");
    if (!stack) {
      stack = document.createElement("div");
      stack.id = "toast-stack";
      document.body.appendChild(stack);
    }
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 3800);
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  function qs(params) {
    const usp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== null && v !== undefined && v !== "" && v !== "all") usp.set(k, v);
    });
    return usp.toString();
  }

  function imgUrl(filename) {
    return filename ? `/uploads/${filename}` : null;
  }

  function initials(name) {
    if (!name) return "?";
    return name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  }

  function stars(rating) {
    const r = Math.round(rating || 0);
    return "★".repeat(r) + "☆".repeat(5 - r);
  }

  // ---- Notifications dropdown / badge (shared across pages via base.html) ----
  async function refreshNotifBadge() {
    const badgeEl = document.getElementById("notif-badge");
    if (!badgeEl) return; // not logged in / no navbar element
    try {
      const data = await api("/notifications");
      if (data.unread_count > 0) {
        badgeEl.textContent = data.unread_count > 9 ? "9+" : data.unread_count;
        badgeEl.style.display = "flex";
      } else {
        badgeEl.style.display = "none";
      }
      const list = document.getElementById("notif-dropdown-list");
      if (list) {
        if (!data.notifications.length) {
          list.innerHTML = `<div class="empty-state" style="padding:30px 16px;"><div class="icon">🔔</div><p style="margin:0">No notifications yet.</p></div>`;
        } else {
          list.innerHTML = data.notifications.slice(0, 8).map(n => `
            <div class="notif-item ${n.is_read ? "" : "unread"}" data-id="${n.id}" data-link="${escapeHtml(n.link || "")}">
              <div class="notif-dot" style="${n.is_read ? "visibility:hidden" : ""}"></div>
              <div>
                <div class="n-title">${escapeHtml(n.title)}</div>
                <div class="n-msg">${escapeHtml(n.message)}</div>
                <div class="n-time">${escapeHtml(n.created_at)}</div>
              </div>
            </div>`).join("");
          list.querySelectorAll(".notif-item").forEach(item => {
            item.addEventListener("click", async () => {
              const id = item.dataset.id;
              await api(`/notifications/${id}/read`, { method: "PUT" });
              const link = item.dataset.link;
              if (link) window.location.href = link;
              else refreshNotifBadge();
            });
          });
        }
      }
    } catch (e) { /* not logged in - ignore */ }
  }

  function setupNavbar() {
    // dropdown toggles
    document.querySelectorAll("[data-dropdown-toggle]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const menu = document.getElementById(btn.dataset.dropdownToggle);
        document.querySelectorAll(".dropdown-menu.open").forEach(m => { if (m !== menu) m.classList.remove("open"); });
        menu.classList.toggle("open");
        if (menu.classList.contains("open") && btn.dataset.dropdownToggle === "notif-dropdown") {
          refreshNotifBadge();
        }
      });
    });
    document.addEventListener("click", () => {
      document.querySelectorAll(".dropdown-menu.open").forEach(m => m.classList.remove("open"));
    });

    const hamburger = document.getElementById("hamburger-btn");
    const drawer = document.getElementById("mobile-drawer");
    if (hamburger && drawer) {
      hamburger.addEventListener("click", () => drawer.classList.add("open"));
      drawer.addEventListener("click", (e) => { if (e.target === drawer) drawer.classList.remove("open"); });
    }

    const markAllBtn = document.getElementById("mark-all-read-btn");
    if (markAllBtn) {
      markAllBtn.addEventListener("click", async () => {
        await api("/notifications/read", { method: "PUT" });
        refreshNotifBadge();
      });
    }

    if (document.body.dataset.loggedIn === "1") {
      refreshNotifBadge();
      setInterval(refreshNotifBadge, 15000); // poll for new notifications
    }

    setupNavbarSearch();
    loadNavbarCategoryPills();
  }

  // ---- OLX-style navbar search bar: submits to the marketplace search ----
  function setupNavbarSearch() {
    const form = document.getElementById("navbar-search-form");
    if (!form) return;
    const input = document.getElementById("navbar-search-input");

    // Pre-fill from the current marketplace search, if any
    const params = new URLSearchParams(window.location.search);
    if (window.location.pathname === "/marketplace" && params.get("q")) {
      input.value = params.get("q");
    }

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = input.value.trim();
      window.location.href = q ? `/marketplace?${qs({ q })}` : "/marketplace";
    });
  }

  // ---- OLX-style category pill row under the navbar ----
  async function loadNavbarCategoryPills() {
    const row = document.getElementById("navbar-category-pills");
    if (!row) return;
    try {
      const data = await api("/listings/categories");
      const params = new URLSearchParams(window.location.search);
      const activeCategory = window.location.pathname === "/marketplace" ? params.get("category") : null;
      row.innerHTML = data.categories.map(c => `
        <a class="category-pill${c.name === activeCategory ? " active" : ""}" href="/marketplace?${qs({ category: c.name })}">${escapeHtml(c.name)}</a>
      `).join("");
    } catch (e) { /* categories failed to load - leave the row empty, non-critical */ }
  }

  async function toggleWishlist(listingId, btnEl) {
    const active = btnEl.classList.contains("active");
    try {
      if (active) {
        await api(`/wishlist/${listingId}`, { method: "DELETE" });
        btnEl.classList.remove("active");
        toast("Removed from wishlist", "info");
      } else {
        await api(`/wishlist/${listingId}`, { method: "POST" });
        btnEl.classList.add("active");
        toast("Added to wishlist", "success");
      }
    } catch (e) {
      if (e.status === 401) {
        window.location.href = "/login";
      } else {
        toast(e.message, "error");
      }
    }
  }

  document.addEventListener("DOMContentLoaded", setupNavbar);

  return { api, toast, escapeHtml, qs, imgUrl, initials, stars, toggleWishlist, refreshNotifBadge };
})();
