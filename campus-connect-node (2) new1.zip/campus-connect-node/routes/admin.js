const express = require("express");
const { fn, col } = require("sequelize");
const {
  User, Listing, Transaction, Report, Event, Category, pushNotification,
} = require("../models");
const { loginRequired, adminRequired } = require("../middleware/auth");

const router = express.Router();

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

router.get("/stats", loginRequired, adminRequired, async (req, res) => {
  const totalUsers = await User.count();
  const verifiedUsers = await User.count({ where: { isVerified: true } });
  const activeListings = await Listing.count({ where: { status: "active" } });
  const completedTransactions = await Transaction.count({ where: { status: "completed" } });
  const pendingReports = await Report.count({ where: { status: "pending" } });
  const { Op } = require("sequelize");
  const upcomingEvents = await Event.count({ where: { date: { [Op.gte]: todayStr() } } });

  const listingsByCategoryRaw = await Listing.findAll({
    attributes: [[col("category.name"), "category"], [fn("COUNT", col("Listing.id")), "count"]],
    include: [{ model: Category, as: "category", attributes: [] }],
    group: ["category.id", "category.name"],
    raw: true,
  });
  const txnByTypeRaw = await Transaction.findAll({
    attributes: ["transactionType", [fn("COUNT", col("id")), "count"]],
    group: ["transactionType"],
    raw: true,
  });

  res.json({
    total_users: totalUsers,
    verified_users: verifiedUsers,
    active_listings: activeListings,
    completed_transactions: completedTransactions,
    pending_reports: pendingReports,
    upcoming_events: upcomingEvents,
    listings_by_category: listingsByCategoryRaw.map((r) => ({ category: r.category, count: parseInt(r.count, 10) })),
    transactions_by_type: txnByTypeRaw.map((r) => ({ type: r.transactionType, count: parseInt(r.count, 10) })),
  });
});

router.get("/users", loginRequired, adminRequired, async (req, res) => {
  const users = await User.findAll({ order: [["createdAt", "DESC"]] });
  const withCounts = await Promise.all(users.map(async (u) => ({
    ...u.toDict(),
    is_suspended: u.isSuspended,
    listing_count: await Listing.count({ where: { sellerId: u.id } }),
  })));
  res.json({ users: withCounts });
});

router.put("/users/:id/suspend", loginRequired, adminRequired, async (req, res) => {
  const user = await User.findByPk(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  if (user.role === "admin") return res.status(400).json({ error: "Cannot suspend an administrator." });
  user.isSuspended = !user.isSuspended;
  await user.save();
  res.json({ message: `User ${user.isSuspended ? "suspended" : "reinstated"}.`, is_suspended: user.isSuspended });
});

router.get("/listings", loginRequired, adminRequired, async (req, res) => {
  const listings = await Listing.findAll({
    order: [["createdAt", "DESC"]],
    include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { association: "images" }],
  });
  res.json({ listings: listings.map((l) => l.toCardDict()) });
});

router.put("/listings/:id/remove", loginRequired, adminRequired, async (req, res) => {
  const listing = await Listing.findByPk(req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  listing.status = "removed";
  await listing.save();
  await pushNotification(
    listing.sellerId, "Listing removed",
    `Your listing "${listing.title}" was removed by a moderator for violating community guidelines.`, "moderation"
  );
  res.json({ message: "Listing removed." });
});

router.get("/reports", loginRequired, adminRequired, async (req, res) => {
  const reports = await Report.findAll({
    order: [["createdAt", "DESC"]],
    include: [
      { model: User, as: "reporter" },
      { model: User, as: "reportedUser" },
      { model: Listing, as: "listing" },
    ],
  });
  res.json({
    reports: reports.map((r) => ({
      id: r.id,
      reporter: r.reporter ? r.reporter.name : null,
      listing: r.listing ? r.listing.title : null,
      listing_id: r.listingId,
      reported_user: r.reportedUser ? r.reportedUser.name : null,
      reported_user_id: r.reportedUserId,
      reason: r.reason,
      description: r.description,
      status: r.status,
      created_at: new Date(r.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
    })),
  });
});

router.put("/reports/:id", loginRequired, adminRequired, async (req, res) => {
  const report = await Report.findByPk(req.params.id);
  if (!report) return res.status(404).json({ error: "Report not found." });
  const { status } = req.body || {};
  if (!["pending", "reviewed", "resolved", "dismissed"].includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }
  report.status = status;
  await report.save();
  res.json({ message: "Report updated." });
});

module.exports = router;
