const express = require("express");
const { Op } = require("sequelize");
const { User, EmailVerification, pushNotification } = require("../models");
const { isUniversityEmail, generateOtp, otpExpiry } = require("../utils/helpers");
const { loginRequired } = require("../middleware/auth");
const config = require("../config");

const router = express.Router();
const VALID_ROLES = new Set(["student", "faculty", "staff"]);

router.post("/register", async (req, res) => {
  const body = req.body || {};
  const name = (body.name || "").trim();
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";
  const confirmPassword = body.confirm_password || "";
  const role = (body.role || "student").trim().toLowerCase();
  const department = (body.department || "").trim();
  const phone = (body.phone || "").trim();

  const errors = {};
  if (!name) errors.name = "Full name is required.";
  if (!email) errors.email = "University email is required.";
  else if (!isUniversityEmail(email)) {
    errors.email = `Please use your official university email (@${config.universityEmailDomain}).`;
  } else if (await User.findOne({ where: { email } })) {
    errors.email = "An account with this email already exists.";
  }
  if (password.length < 6) errors.password = "Password must be at least 6 characters.";
  if (password !== confirmPassword) errors.confirm_password = "Passwords do not match.";
  if (!VALID_ROLES.has(role)) errors.role = "Invalid user type.";
  if (!department) errors.department = "Department is required.";

  if (Object.keys(errors).length) {
    return res.status(400).json({ error: "Please fix the errors below.", fields: errors });
  }

  const user = User.build({ name, email, role, department, phone });
  user.setPassword(password);
  await user.save();

  const otp = generateOtp();
  await EmailVerification.create({ userId: user.id, otpCode: otp, expiresAt: otpExpiry() });

  req.session.userId = user.id;

  const response = { message: "Account created. Please verify your university email.", user: user.toDict() };
  if (config.demoMode) response.demo_otp = otp;
  res.status(201).json(response);
});

router.post("/verify", loginRequired, async (req, res) => {
  const otpCode = ((req.body && req.body.otp_code) || "").trim();

  if (req.user.isVerified) {
    return res.json({ message: "Account already verified.", user: req.user.toDict() });
  }

  const verification = await EmailVerification.findOne({
    where: { userId: req.user.id, isUsed: false },
    order: [["createdAt", "DESC"]],
  });
  if (!verification) return res.status(400).json({ error: "No pending verification found. Request a new code." });
  if (verification.expiresAt < new Date()) return res.status(400).json({ error: "This code has expired. Request a new code." });
  if (verification.otpCode !== otpCode) return res.status(400).json({ error: "Incorrect verification code." });

  verification.isUsed = true;
  await verification.save();
  req.user.isVerified = true;
  await req.user.save();

  await pushNotification(
    req.user.id, "Welcome to Campus Connect!",
    "Your university email is verified. You can now buy, sell, rent and exchange.", "system"
  );

  res.json({ message: "Email verified successfully.", user: req.user.toDict() });
});

router.post("/resend-otp", loginRequired, async (req, res) => {
  if (req.user.isVerified) return res.json({ message: "Account already verified." });

  const otp = generateOtp();
  await EmailVerification.create({ userId: req.user.id, otpCode: otp, expiresAt: otpExpiry() });

  const response = { message: "A new verification code has been generated." };
  if (config.demoMode) response.demo_otp = otp;
  res.json(response);
});

router.post("/login", async (req, res) => {
  const body = req.body || {};
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";

  const user = await User.findOne({ where: { email } });
  if (!user || !user.checkPassword(password)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }
  if (user.isSuspended) {
    return res.status(403).json({ error: "This account has been suspended. Contact an administrator." });
  }

  req.session.userId = user.id;
  if (body.remember) req.session.cookie.maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days

  res.json({ message: "Login successful.", user: user.toDict() });
});

router.post("/logout", loginRequired, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ message: "Logged out successfully." });
  });
});

router.get("/me", (req, res) => {
  res.json({ user: req.user ? req.user.toDict() : null });
});

const { upload } = require("../utils/helpers");

router.put("/me", loginRequired, upload.single("profile_image"), async (req, res) => {
  const body = req.body || {};
  ["name", "department", "phone", "bio"].forEach((field) => {
    if (body[field] !== undefined) req.user[field] = body[field];
  });
  if (req.file) req.user.profileImage = req.file.filename;
  await req.user.save();
  res.json({ message: "Profile updated.", user: req.user.toDict() });
});

module.exports = router;
