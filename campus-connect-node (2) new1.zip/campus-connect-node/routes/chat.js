const express = require("express");
const { Op } = require("sequelize");
const { Conversation, Message, Listing, Category, User, ListingImage, pushNotification } = require("../models");
const { loginRequired, verifiedRequired } = require("../middleware/auth");

const router = express.Router();

router.get("/conversations", loginRequired, async (req, res) => {
  const convos = await Conversation.findAll({
    where: { [Op.or]: [{ user1Id: req.user.id }, { user2Id: req.user.id }] },
    order: [["createdAt", "DESC"]],
    include: [
      { model: Listing, as: "listing", include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }] },
      { model: User, as: "user1" },
      { model: User, as: "user2" },
      { model: Message, as: "messages" },
    ],
  });

  const result = convos.map((c) => {
    const other = c.user1Id === req.user.id ? c.user2 : c.user1;
    const msgs = [...c.messages].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    const last = msgs.length ? msgs[msgs.length - 1] : null;
    const unread = msgs.filter((m) => !m.isRead && m.senderId !== req.user.id).length;
    return {
      id: c.id,
      listing: c.listing ? c.listing.toCardDict() : null,
      other_user: other ? other.toPublicDict() : null,
      last_message: last ? last.message : null,
      last_message_at: last ? new Date(last.createdAt).toLocaleString("en-US", { month: "short", day: "2-digit", hour: "numeric", minute: "2-digit", hour12: true }) : null,
      last_message_raw: last ? new Date(last.createdAt).getTime() : 0,
      unread_count: unread,
    };
  });
  result.sort((a, b) => b.last_message_raw - a.last_message_raw);
  result.forEach((r) => delete r.last_message_raw);

  res.json({ conversations: result });
});

router.post("/conversations", loginRequired, verifiedRequired, async (req, res) => {
  const listingId = req.body.listing_id;
  const listing = await Listing.findByPk(listingId);
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  if (listing.sellerId === req.user.id) {
    return res.status(400).json({ error: "You cannot start a conversation with yourself." });
  }

  let convo = await Conversation.findOne({ where: { listingId, user1Id: req.user.id, user2Id: listing.sellerId } });
  if (!convo) convo = await Conversation.findOne({ where: { listingId, user1Id: listing.sellerId, user2Id: req.user.id } });
  if (!convo) convo = await Conversation.create({ listingId, user1Id: req.user.id, user2Id: listing.sellerId });

  res.status(201).json({ conversation_id: convo.id });
});

router.get("/conversations/:id/messages", loginRequired, async (req, res) => {
  const convo = await Conversation.findByPk(req.params.id, {
    include: [
      { model: Listing, as: "listing", include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }] },
      { model: User, as: "user1" },
      { model: User, as: "user2" },
    ],
  });
  if (!convo) return res.status(404).json({ error: "Conversation not found." });
  if (req.user.id !== convo.user1Id && req.user.id !== convo.user2Id) {
    return res.status(403).json({ error: "Not authorized to view this conversation." });
  }

  await Message.update(
    { isRead: true },
    { where: { conversationId: convo.id, senderId: { [Op.ne]: req.user.id }, isRead: false } }
  );

  const msgs = await Message.findAll({
    where: { conversationId: convo.id },
    order: [["createdAt", "ASC"]],
    include: [{ model: User, as: "sender" }],
  });
  const other = convo.user1Id === req.user.id ? convo.user2 : convo.user1;

  res.json({
    listing: convo.listing ? convo.listing.toCardDict() : null,
    other_user: other ? other.toPublicDict() : null,
    messages: msgs.map((m) => ({
      id: m.id,
      sender_id: m.senderId,
      sender_name: m.sender.name,
      message: m.message,
      is_mine: m.senderId === req.user.id,
      created_at: new Date(m.createdAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true }),
      created_date: new Date(m.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
    })),
  });
});

router.post("/conversations/:id/messages", loginRequired, verifiedRequired, async (req, res) => {
  const convo = await Conversation.findByPk(req.params.id);
  if (!convo) return res.status(404).json({ error: "Conversation not found." });
  if (req.user.id !== convo.user1Id && req.user.id !== convo.user2Id) {
    return res.status(403).json({ error: "Not authorized to message in this conversation." });
  }

  const text = ((req.body && req.body.message) || "").trim();
  if (!text) return res.status(400).json({ error: "Message cannot be empty." });

  const msg = await Message.create({ conversationId: convo.id, senderId: req.user.id, message: text });
  const otherId = convo.user1Id === req.user.id ? convo.user2Id : convo.user1Id;
  await pushNotification(otherId, "New message", `${req.user.name} sent you a message.`, "message", `/messages/${convo.id}`);

  res.status(201).json({
    id: msg.id, sender_id: msg.senderId, message: msg.message, is_mine: true,
    created_at: new Date(msg.createdAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true }),
  });
});

module.exports = router;
