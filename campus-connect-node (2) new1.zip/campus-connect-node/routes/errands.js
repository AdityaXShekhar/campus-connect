const express = require("express");
const { ErrandRequest, User, pushNotification } = require("../models");
const { loginRequired, verifiedRequired } = require("../middleware/auth");

const router = express.Router();
const includeFull = [{ model: User, as: "requester" }, { model: User, as: "helper" }];

router.get("/", async (req, res) => {
  const status = req.query.status || "open";
  const where = {};
  if (status && status !== "all") where.status = status;
  const errands = await ErrandRequest.findAll({ where, order: [["createdAt", "DESC"]], include: includeFull });
  res.json({ errands: errands.map((e) => e.toDict()) });
});

router.get("/:id", async (req, res) => {
  const errand = await ErrandRequest.findByPk(req.params.id, { include: includeFull });
  if (!errand) return res.status(404).json({ error: "Errand not found." });
  res.json({ errand: errand.toDict() });
});

router.post("/", loginRequired, verifiedRequired, async (req, res) => {
  const body = req.body || {};
  const title = (body.title || "").trim();
  const pickup = (body.pickup_location || "").trim();
  const destination = (body.destination || "").trim();

  const errors = {};
  if (!title) errors.title = "Title is required.";
  if (!pickup) errors.pickup_location = "Pickup location is required.";
  if (!destination) errors.destination = "Destination is required.";
  if (!body.date) errors.date = "Date is required.";
  if (Object.keys(errors).length) return res.status(400).json({ error: "Please fix the errors below.", fields: errors });

  const errand = await ErrandRequest.create({
    requesterId: req.user.id, title, description: body.description || "",
    pickupLocation: pickup, destination, date: body.date, reward: body.reward || "", status: "open",
  });
  const full = await ErrandRequest.findByPk(errand.id, { include: includeFull });
  res.status(201).json({ message: "Errand request posted.", errand: full.toDict() });
});

router.put("/:id", loginRequired, async (req, res) => {
  const errand = await ErrandRequest.findByPk(req.params.id, { include: includeFull });
  if (!errand) return res.status(404).json({ error: "Errand not found." });
  const action = req.body.action;

  if (action === "accept") {
    if (errand.status !== "open") return res.status(400).json({ error: "This errand is no longer open." });
    if (errand.requesterId === req.user.id) return res.status(400).json({ error: "You cannot accept your own errand request." });
    errand.status = "accepted";
    errand.acceptedBy = req.user.id;
    await pushNotification(errand.requesterId, "Errand accepted!", `${req.user.name} offered to help with "${errand.title}".`, "errand");
  } else if (action === "complete") {
    if (errand.requesterId !== req.user.id && errand.acceptedBy !== req.user.id) return res.status(403).json({ error: "Not authorized." });
    errand.status = "completed";
  } else if (action === "cancel") {
    if (errand.requesterId !== req.user.id) return res.status(403).json({ error: "Only the requester can cancel." });
    errand.status = "cancelled";
  } else {
    return res.status(400).json({ error: "Unknown action." });
  }

  await errand.save();
  const full = await ErrandRequest.findByPk(errand.id, { include: includeFull });
  res.json({ message: "Errand updated.", errand: full.toDict() });
});

module.exports = router;
