const express = require("express");
const { Op } = require("sequelize");
const { Event, User, pushNotification } = require("../models");
const { loginRequired, adminRequired } = require("../middleware/auth");

const router = express.Router();

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

router.get("/", async (req, res) => {
  const scope = req.query.scope || "upcoming";
  const where = {};
  if (scope === "upcoming") where.date = { [Op.gte]: todayStr() };
  else if (scope === "past") where.date = { [Op.lt]: todayStr() };

  const events = await Event.findAll({ where, order: [["date", "ASC"]] });
  res.json({ events: events.map((e) => e.toDict()) });
});

router.get("/:id", async (req, res) => {
  const event = await Event.findByPk(req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found." });
  res.json({ event: event.toDict() });
});

router.post("/", loginRequired, adminRequired, async (req, res) => {
  const body = req.body || {};
  const title = (body.title || "").trim();
  if (!title || !body.date) return res.status(400).json({ error: "Title and date are required." });

  const event = await Event.create({
    title,
    description: body.description || "",
    category: body.category || "Campus Fest",
    date: body.date,
    time: body.time || "",
    location: body.location || "",
    organizer: body.organizer || "",
    image: body.image || null,
    createdBy: req.user.id,
  });

  const users = await User.findAll({ where: { isVerified: true } });
  await Promise.all(users.map((u) => pushNotification(u.id, "New campus event", `"${title}" was just announced.`, "event", "/events")));

  res.status(201).json({ message: "Event created.", event: event.toDict() });
});

router.put("/:id", loginRequired, adminRequired, async (req, res) => {
  const event = await Event.findByPk(req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found." });
  const body = req.body || {};
  ["title", "description", "category", "time", "location", "organizer", "image"].forEach((f) => {
    if (body[f] !== undefined) event[f] = body[f];
  });
  if (body.date) event.date = body.date;
  await event.save();
  res.json({ message: "Event updated.", event: event.toDict() });
});

router.delete("/:id", loginRequired, adminRequired, async (req, res) => {
  const event = await Event.findByPk(req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found." });
  await event.destroy();
  res.json({ message: "Event deleted." });
});

module.exports = router;
