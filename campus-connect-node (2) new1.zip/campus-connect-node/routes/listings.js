const express = require("express");
const { Op } = require("sequelize");
const { Listing, ListingImage, Category, User } = require("../models");
const { loginRequired, verifiedRequired } = require("../middleware/auth");
const { upload } = require("../utils/helpers");
const config = require("../config");

const router = express.Router();

router.get("/", async (req, res) => {
  const q = (req.query.q || "").trim();
  const category = req.query.category;
  const txnType = req.query.type;
  const condition = req.query.condition;
  const location = (req.query.location || "").trim();
  const minPrice = req.query.min_price ? parseFloat(req.query.min_price) : null;
  const maxPrice = req.query.max_price ? parseFloat(req.query.max_price) : null;
  const datePosted = req.query.date_posted;
  const sellerId = req.query.seller_id ? parseInt(req.query.seller_id, 10) : null;
  const sort = req.query.sort || "newest";
  const page = parseInt(req.query.page, 10) || 1;
  const perPage = config.listingsPerPage;

  const where = {};
  const include = [
    { model: Category, as: "category" },
    { model: User, as: "seller" },
    { model: ListingImage, as: "images" },
  ];

  if (sellerId) {
    where.sellerId = sellerId;
    if (req.query.status) where.status = req.query.status;
  } else {
    where.status = "active";
  }

  if (q) {
    where[Op.or] = [{ title: { [Op.like]: `%${q}%` } }, { description: { [Op.like]: `%${q}%` } }];
  }
  if (category && category !== "all") {
    include[0].where = { name: category };
  }
  if (txnType && txnType !== "all") where.transactionType = txnType;
  if (condition && condition !== "all") where.condition = condition;
  if (location) where.location = { [Op.like]: `%${location}%` };
  if (minPrice !== null) where.price = { ...(where.price || {}), [Op.gte]: minPrice };
  if (maxPrice !== null) where.price = { ...(where.price || {}), [Op.lte]: maxPrice };
  if (datePosted) {
    const now = new Date();
    let since;
    if (datePosted === "today") since = new Date(now - 24 * 3600 * 1000);
    else if (datePosted === "week") since = new Date(now - 7 * 24 * 3600 * 1000);
    else if (datePosted === "month") since = new Date(now - 30 * 24 * 3600 * 1000);
    if (since) where.createdAt = { [Op.gte]: since };
  }

  let order = [["createdAt", "DESC"]];
  if (sort === "oldest") order = [["createdAt", "ASC"]];
  else if (sort === "price_low") order = [["price", "ASC"]];
  else if (sort === "price_high") order = [["price", "DESC"]];

  const { rows, count } = await Listing.findAndCountAll({
    where, include, order, distinct: true,
    limit: perPage, offset: (page - 1) * perPage,
  });

  res.json({
    listings: rows.map((l) => l.toCardDict()),
    total: count,
    page,
    pages: Math.max(1, Math.ceil(count / perPage)),
    has_next: page * perPage < count,
    has_prev: page > 1,
  });
});

router.get("/categories", async (req, res) => {
  const categories = await Category.findAll({ order: [["name", "ASC"]] });
  res.json({ categories: categories.map((c) => ({ id: c.id, name: c.name, icon: c.icon })) });
});

router.get("/:id", async (req, res) => {
  const listing = await Listing.findByPk(req.params.id, {
    include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }],
  });
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  listing.views = (listing.views || 0) + 1;
  await listing.save();
  res.json({ listing: listing.toDetailDict() });
});

router.post("/", loginRequired, verifiedRequired, upload.array("images", 6), async (req, res) => {
  const body = req.body || {};
  const title = (body.title || "").trim();
  const description = (body.description || "").trim();
  const categoryId = parseInt(body.category_id, 10);
  const transactionType = (body.transaction_type || "").trim().toLowerCase();
  const condition = (body.condition || "Good").trim();
  const location = (body.location || "").trim();
  const exchangePreference = (body.exchange_preference || "").trim();

  const errors = {};
  if (!title) errors.title = "Title is required.";
  if (!description) errors.description = "Description is required.";
  const category = categoryId ? await Category.findByPk(categoryId) : null;
  if (!category) errors.category_id = "Please select a valid category.";
  if (!["sell", "rent", "exchange", "buy"].includes(transactionType)) {
    errors.transaction_type = "Please select a valid transaction type.";
  }
  const price = parseFloat(body.price);
  if (Number.isNaN(price) || price < 0) errors.price = "Please enter a valid price (0 or more).";

  if (Object.keys(errors).length) {
    return res.status(400).json({ error: "Please fix the errors below.", fields: errors });
  }

  const listing = await Listing.create({
    sellerId: req.user.id,
    title,
    description,
    categoryId,
    transactionType,
    price,
    condition,
    location: location || "On campus",
    exchangePreference: transactionType === "exchange" ? exchangePreference : null,
    availableFrom: body.available_from || null,
    availableUntil: body.available_until || null,
  });

  const files = req.files || [];
  for (const f of files.slice(0, 6)) {
    await ListingImage.create({ listingId: listing.id, imagePath: f.filename });
  }

  const full = await Listing.findByPk(listing.id, {
    include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }],
  });
  res.status(201).json({ message: "Listing created successfully.", listing: full.toDetailDict() });
});

router.put("/:id", loginRequired, upload.array("images", 6), async (req, res) => {
  const listing = await Listing.findByPk(req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  if (listing.sellerId !== req.user.id && req.user.role !== "admin") {
    return res.status(403).json({ error: "You can only edit your own listings." });
  }

  const body = req.body || {};
  ["title", "description", "location", "condition", "exchangePreference"].forEach((field) => {
    const key = field === "exchangePreference" ? "exchange_preference" : field;
    if (body[key] !== undefined) listing[field] = body[key];
  });
  if (body.category_id) listing.categoryId = parseInt(body.category_id, 10);
  if (body.transaction_type) listing.transactionType = body.transaction_type;
  if (body.price !== undefined && body.price !== "") listing.price = parseFloat(body.price);
  if (body.status && ["active", "reserved", "completed", "removed"].includes(body.status)) listing.status = body.status;
  if (body.available_from) listing.availableFrom = body.available_from;
  if (body.available_until) listing.availableUntil = body.available_until;

  await listing.save();

  const files = req.files || [];
  for (const f of files.slice(0, 6)) {
    await ListingImage.create({ listingId: listing.id, imagePath: f.filename });
  }

  const full = await Listing.findByPk(listing.id, {
    include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }],
  });
  res.json({ message: "Listing updated successfully.", listing: full.toDetailDict() });
});

router.delete("/:id", loginRequired, async (req, res) => {
  const listing = await Listing.findByPk(req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  if (listing.sellerId !== req.user.id && req.user.role !== "admin") {
    return res.status(403).json({ error: "You can only delete your own listings." });
  }
  await listing.destroy();
  res.json({ message: "Listing deleted successfully." });
});

module.exports = router;
