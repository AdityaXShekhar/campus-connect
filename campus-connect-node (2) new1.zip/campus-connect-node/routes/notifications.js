const express = require("express");
const { Notification } = require("../models");
const { loginRequired } = require("../middleware/auth");

const router = express.Router();

router.get("/", loginRequired, async (req, res) => {
  const notes = await Notification.findAll({ where: { userId: req.user.id }, order: [["createdAt", "DESC"]], limit: 50 });
  const unreadCount = await Notification.count({ where: { userId: req.user.id, isRead: false } });
  res.json({ notifications: notes.map((n) => n.toDict()), unread_count: unreadCount });
});

router.put("/read", loginRequired, async (req, res) => {
  await Notification.update({ isRead: true }, { where: { userId: req.user.id, isRead: false } });
  res.json({ message: "All notifications marked as read." });
});

router.put("/:id/read", loginRequired, async (req, res) => {
  const note = await Notification.findByPk(req.params.id);
  if (!note) return res.status(404).json({ error: "Notification not found." });
  if (note.userId !== req.user.id) return res.status(403).json({ error: "Not authorized." });
  note.isRead = true;
  await note.save();
  res.json({ message: "Marked as read." });
});

module.exports = router;
