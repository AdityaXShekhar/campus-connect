const express = require("express");
const { Category, User, Listing } = require("../models");
const { loginRequired, adminRequired } = require("../middleware/auth");
const config = require("../config");

const router = express.Router();

router.get("/", async (req, res) => {
  res.render("index", { title: "Home" });
});

router.get("/register", (req, res) => {
  if (req.user) return res.redirect("/marketplace");
  res.render("register", { title: "Create your account", university_domain: config.universityEmailDomain });
});

router.get("/login", (req, res) => {
  if (req.user) return res.redirect("/marketplace");
  res.render("login", { title: "Log in" });
});

router.get("/verify", loginRequired, (req, res) => {
  if (req.user.isVerified) return res.redirect("/marketplace");
  res.render("verify", { title: "Verify your email" });
});

router.get("/marketplace", async (req, res) => {
  const categories = await Category.findAll({ order: [["name", "ASC"]] });
  res.render("marketplace", { title: "Marketplace", categories });
});

router.get("/listing/create", loginRequired, async (req, res) => {
  const categories = await Category.findAll({ order: [["name", "ASC"]] });
  res.render("create_listing", { title: "Create Listing", categories });
});

router.get("/listing/:id", async (req, res) => {
  const listing = await Listing.findByPk(req.params.id, {
    include: [
      { association: "category" },
      { association: "seller" },
      { association: "images" },
    ],
  });
  if (!listing) return res.status(404).render("errors/404");
  res.render("listing_detail", { title: listing.title, listing });
});

router.get("/listing/:id/edit", loginRequired, async (req, res) => {
  const listing = await Listing.findByPk(req.params.id, { include: [{ association: "images" }] });
  if (!listing) return res.status(404).render("errors/404");
  if (listing.sellerId !== req.user.id && req.user.role !== "admin") return res.status(403).render("errors/403");
  const categories = await Category.findAll({ order: [["name", "ASC"]] });
  res.render("edit_listing", { title: "Edit Listing", listing, categories });
});

router.get("/my-listings", loginRequired, (req, res) => res.render("my_listings", { title: "My Listings" }));

router.get("/wishlist", loginRequired, (req, res) => res.render("wishlist", { title: "Wishlist" }));

router.get("/messages", loginRequired, (req, res) => res.render("messages", { title: "Messages", active_conversation_id: null }));

router.get("/messages/:id", loginRequired, (req, res) =>
  res.render("messages", { title: "Messages", active_conversation_id: parseInt(req.params.id, 10) }));

router.get("/transactions", loginRequired, (req, res) => res.render("transactions", { title: "Transactions" }));

router.get("/profile", loginRequired, (req, res) =>
  res.render("profile", { title: "My Profile", profile_user: req.user, is_own_profile: true }));

router.get("/profile/edit", loginRequired, (req, res) => res.render("edit_profile", { title: "Edit Profile" }));

router.get("/profile/:id", async (req, res) => {
  const profileUser = await User.findByPk(req.params.id);
  if (!profileUser) return res.status(404).render("errors/404");
  const isOwn = !!(req.user && req.user.id === profileUser.id);
  res.render("profile", { title: profileUser.name, profile_user: profileUser, is_own_profile: isOwn });
});

router.get("/events", (req, res) => res.render("events", { title: "Campus Events" }));

router.get("/errands", (req, res) => res.render("errands", { title: "Errand Requests" }));

router.get("/errands/create", loginRequired, (req, res) => res.render("create_errand", { title: "Post an Errand" }));

router.get("/notifications", loginRequired, (req, res) => res.render("notifications", { title: "Notifications" }));

// --- Admin pages ---
router.get("/admin", loginRequired, adminRequired, (req, res) => res.render("admin/dashboard", { title: "Admin Dashboard" }));
router.get("/admin/users", loginRequired, adminRequired, (req, res) => res.render("admin/users", { title: "Admin · Users" }));
router.get("/admin/listings", loginRequired, adminRequired, (req, res) => res.render("admin/listings", { title: "Admin · Listings" }));
router.get("/admin/reports", loginRequired, adminRequired, (req, res) => res.render("admin/reports", { title: "Admin · Reports" }));
router.get("/admin/events", loginRequired, adminRequired, (req, res) => res.render("admin/events", { title: "Admin · Events" }));

module.exports = router;
