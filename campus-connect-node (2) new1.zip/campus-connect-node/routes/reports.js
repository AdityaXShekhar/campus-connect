const express = require("express");
const { Report, Listing } = require("../models");
const { loginRequired } = require("../middleware/auth");

const router = express.Router();
const VALID_REASONS = new Set(["Scam", "Fake product", "Inappropriate content", "Wrong information", "Harassment", "Other"]);

router.post("/", loginRequired, async (req, res) => {
  const { listing_id: listingId, reason, description } = req.body || {};
  if (!VALID_REASONS.has(reason)) return res.status(400).json({ error: "Please select a valid reason." });

  let reportedUserId = null;
  if (listingId) {
    const listing = await Listing.findByPk(listingId);
    if (!listing) return res.status(404).json({ error: "Listing not found." });
    reportedUserId = listing.sellerId;
  }

  await Report.create({
    reporterId: req.user.id, listingId: listingId || null, reportedUserId,
    reason, description: (description || "").trim(), status: "pending",
  });

  res.status(201).json({ message: "Thanks - our moderators will review this report." });
});

module.exports = router;
