const express = require("express");
const { Review, Transaction, User, pushNotification } = require("../models");
const { loginRequired } = require("../middleware/auth");

const router = express.Router();

router.post("/", loginRequired, async (req, res) => {
  const { transaction_id: transactionId, rating: ratingRaw, comment } = req.body || {};
  const txn = await Transaction.findByPk(transactionId);
  if (!txn) return res.status(404).json({ error: "Transaction not found." });
  if (req.user.id !== txn.buyerId && req.user.id !== txn.sellerId) {
    return res.status(403).json({ error: "Not authorized to review this transaction." });
  }
  if (txn.status !== "completed") return res.status(400).json({ error: "You can only review completed transactions." });

  const rating = parseInt(ratingRaw, 10);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    return res.status(400).json({ error: "Rating must be between 1 and 5." });
  }

  const existing = await Review.findOne({ where: { transactionId, reviewerId: req.user.id } });
  if (existing) return res.status(400).json({ error: "You already reviewed this transaction." });

  const reviewedUserId = req.user.id === txn.buyerId ? txn.sellerId : txn.buyerId;

  await Review.create({
    transactionId, reviewerId: req.user.id, reviewedUserId, rating, comment: (comment || "").trim(),
  });

  const reviewedUser = await User.findByPk(reviewedUserId);
  const totalScore = (reviewedUser.rating || 0) * (reviewedUser.ratingCount || 0) + rating;
  reviewedUser.ratingCount = (reviewedUser.ratingCount || 0) + 1;
  reviewedUser.rating = Math.round((totalScore / reviewedUser.ratingCount) * 100) / 100;
  await reviewedUser.save();

  await pushNotification(reviewedUserId, "You received a new review", `${req.user.name} rated you ${rating} star(s).`, "review");

  res.status(201).json({ message: "Review submitted. Thank you!" });
});

router.get("/user/:userId", async (req, res) => {
  const reviews = await Review.findAll({
    where: { reviewedUserId: req.params.userId },
    order: [["createdAt", "DESC"]],
    include: [{ model: User, as: "reviewer" }],
  });
  res.json({
    reviews: reviews.map((r) => ({
      id: r.id,
      reviewer_name: r.reviewer.name,
      rating: r.rating,
      comment: r.comment,
      created_at: new Date(r.createdAt).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }),
    })),
  });
});

module.exports = router;
