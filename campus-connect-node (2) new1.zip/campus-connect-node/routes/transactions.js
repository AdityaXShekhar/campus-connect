const express = require("express");
const { Op } = require("sequelize");
const { Transaction, Listing, Category, User, ListingImage, pushNotification } = require("../models");
const { loginRequired, verifiedRequired } = require("../middleware/auth");

const router = express.Router();

const includeFull = [
  { model: Listing, as: "listing", include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }] },
  { model: User, as: "buyer" },
  { model: User, as: "seller" },
];

router.get("/", loginRequired, async (req, res) => {
  const role = req.query.role;
  const where = {};
  if (role === "buyer") where.buyerId = req.user.id;
  else if (role === "seller") where.sellerId = req.user.id;
  else where[Op.or] = [{ buyerId: req.user.id }, { sellerId: req.user.id }];
  if (req.query.status) where.status = req.query.status;

  const txns = await Transaction.findAll({ where, order: [["createdAt", "DESC"]], include: includeFull });
  res.json({ transactions: txns.map((t) => t.toDict()) });
});

router.post("/", loginRequired, verifiedRequired, async (req, res) => {
  const listingId = req.body.listing_id;
  const listing = await Listing.findByPk(listingId);
  if (!listing) return res.status(404).json({ error: "Listing not found." });
  if (listing.sellerId === req.user.id) return res.status(400).json({ error: "You cannot request your own listing." });
  if (listing.status !== "active") return res.status(400).json({ error: "This listing is no longer available." });

  const txnType = req.body.transaction_type || listing.transactionType;
  const data = {
    listingId: listing.id, buyerId: req.user.id, sellerId: listing.sellerId,
    transactionType: txnType, status: "pending",
  };

  if (txnType === "rent") {
    if (!req.body.rental_start || !req.body.rental_end) {
      return res.status(400).json({ error: "Please provide rental start and end dates." });
    }
    data.rentalStart = req.body.rental_start;
    data.rentalEnd = req.body.rental_end;
  }
  if (txnType === "exchange") data.exchangeOffer = req.body.exchange_offer || "";

  const txn = await Transaction.create(data);
  listing.status = "reserved";
  await listing.save();

  await pushNotification(
    listing.sellerId, "New request on your listing",
    `${req.user.name} requested to ${txnType} "${listing.title}".`, "transaction", "/transactions"
  );

  const full = await Transaction.findByPk(txn.id, { include: includeFull });
  res.status(201).json({ message: "Request sent to the seller.", transaction: full.toDict() });
});

router.put("/:id", loginRequired, async (req, res) => {
  const txn = await Transaction.findByPk(req.params.id, { include: includeFull });
  if (!txn) return res.status(404).json({ error: "Transaction not found." });

  const action = req.body.action;
  const isSeller = req.user.id === txn.sellerId;
  const isBuyer = req.user.id === txn.buyerId;
  if (!isSeller && !isBuyer) return res.status(403).json({ error: "Not authorized for this transaction." });

  const listing = await Listing.findByPk(txn.listingId);

  if (action === "accept") {
    if (!isSeller) return res.status(403).json({ error: "Only the seller can accept a request." });
    txn.status = "accepted";
    await pushNotification(txn.buyerId, "Request accepted!", `${req.user.name} accepted your request for "${txn.listing.title}".`, "transaction");
  } else if (action === "reject") {
    if (!isSeller) return res.status(403).json({ error: "Only the seller can reject a request." });
    txn.status = "rejected";
    if (listing) { listing.status = "active"; await listing.save(); }
    await pushNotification(txn.buyerId, "Request declined", `${req.user.name} declined your request for "${txn.listing.title}".`, "transaction");
  } else if (action === "cancel") {
    txn.status = "cancelled";
    if (listing) { listing.status = "active"; await listing.save(); }
    const otherId = isBuyer ? txn.sellerId : txn.buyerId;
    await pushNotification(otherId, "Request cancelled", `A request for "${txn.listing.title}" was cancelled.`, "transaction");
  } else if (action === "confirm") {
    if (txn.status !== "accepted") return res.status(400).json({ error: "Transaction must be accepted before it can be completed." });
    if (isBuyer) txn.buyerConfirmed = true;
    if (isSeller) txn.sellerConfirmed = true;
    if (txn.buyerConfirmed && txn.sellerConfirmed) {
      txn.status = "completed";
      txn.completedAt = new Date();
      if (listing) { listing.status = "completed"; await listing.save(); }
      await pushNotification(txn.buyerId, "Transaction completed", `Your transaction for "${txn.listing.title}" is complete. Leave a review!`, "transaction");
      await pushNotification(txn.sellerId, "Transaction completed", `Your transaction for "${txn.listing.title}" is complete. Leave a review!`, "transaction");
    }
  } else {
    return res.status(400).json({ error: "Unknown action." });
  }

  await txn.save();
  const full = await Transaction.findByPk(txn.id, { include: includeFull });
  res.json({ message: "Transaction updated.", transaction: full.toDict() });
});

module.exports = router;
