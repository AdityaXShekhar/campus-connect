const express = require("express");
const { Wishlist, Listing, Category, User, ListingImage } = require("../models");
const { loginRequired } = require("../middleware/auth");

const router = express.Router();

router.get("/", loginRequired, async (req, res) => {
  const items = await Wishlist.findAll({
    where: { userId: req.user.id },
    order: [["createdAt", "DESC"]],
    include: [{
      model: Listing, as: "listing",
      include: [{ model: Category, as: "category" }, { model: User, as: "seller" }, { model: ListingImage, as: "images" }],
    }],
  });
  const wishlist = items.filter((i) => i.listing).map((i) => ({ ...i.listing.toCardDict(), wishlist_id: i.id }));
  res.json({ wishlist });
});

router.post("/:listingId", loginRequired, async (req, res) => {
  const listing = await Listing.findByPk(req.params.listingId);
  if (!listing) return res.status(404).json({ error: "Listing not found." });

  const existing = await Wishlist.findOne({ where: { userId: req.user.id, listingId: listing.id } });
  if (existing) return res.json({ message: "Already in your wishlist.", in_wishlist: true });

  await Wishlist.create({ userId: req.user.id, listingId: listing.id });
  res.status(201).json({ message: "Added to wishlist.", in_wishlist: true });
});

router.delete("/:listingId", loginRequired, async (req, res) => {
  const item = await Wishlist.findOne({ where: { userId: req.user.id, listingId: req.params.listingId } });
  if (!item) return res.status(404).json({ error: "Not in wishlist." });
  await item.destroy();
  res.json({ message: "Removed from wishlist.", in_wishlist: false });
});

module.exports = router;
