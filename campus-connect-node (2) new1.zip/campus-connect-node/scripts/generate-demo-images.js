/**
 * Campus Connect — demo image generator
 * -----------------------------------------
 * Generates a simple, good-looking placeholder cover image for each
 * marketplace category (SVG — no external image libraries, no internet
 * connection needed, so it always works the same way on every machine).
 *
 * These are used by seed.js so demo listings show a photo instead of the
 * generic "no image" box. Re-run any time with: node scripts/generate-demo-images.js
 *
 * To use REAL photos instead: just edit a listing (Edit Listing page) and
 * upload a real JPG/PNG — that goes through the normal upload flow and
 * overrides these placeholders. This script only affects the seed data.
 */

const fs = require("fs");
const path = require("path");

const OUT_DIR = path.join(__dirname, "..", "uploads");
fs.mkdirSync(OUT_DIR, { recursive: true });

// category name -> [gradient start, gradient end, emoji]
const CATEGORY_STYLE = {
  "Books": ["#3B82F6", "#1D4ED8", "📚"],
  "Electronics": ["#A78BFA", "#6D28D9", "💻"],
  "Furniture": ["#D97706", "#92400E", "🪑"],
  "Hostel Essentials": ["#38BDF8", "#0369A1", "🧺"],
  "Clothing": ["#F472B6", "#BE185D", "👕"],
  "Sports": ["#4ADE80", "#15803D", "⚽"],
  "Lab Equipment": ["#22D3EE", "#0E7490", "🧪"],
  "Stationery": ["#FBBF24", "#B45309", "✏️"],
  "Bicycles": ["#F87171", "#B91C1C", "🚲"],
  "Appliances": ["#818CF8", "#3730A3", "🔌"],
  "Notes & Study Material": ["#34D399", "#047857", "📝"],
  "Other": ["#94A3B8", "#475569", "📦"],
};

function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function svgFor(categoryName, [start, end, emoji]) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${start}"/>
      <stop offset="100%" stop-color="${end}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="300" fill="url(#g)"/>
  <text x="200" y="145" font-size="88" text-anchor="middle" dominant-baseline="central">${emoji}</text>
  <text x="200" y="235" font-size="21" font-family="Verdana, sans-serif" font-weight="700"
        text-anchor="middle" fill="rgba(255,255,255,0.94)">${categoryName}</text>
</svg>`;
}

const written = [];
for (const [name, style] of Object.entries(CATEGORY_STYLE)) {
  const filename = `category-${slugify(name)}.svg`;
  fs.writeFileSync(path.join(OUT_DIR, filename), svgFor(name, style));
  written.push(filename);
}

console.log(`Generated ${written.length} placeholder images in uploads/:`);
written.forEach((f) => console.log(`  - ${f}`));

module.exports = { CATEGORY_STYLE, slugify };
