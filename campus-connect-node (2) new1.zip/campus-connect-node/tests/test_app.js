/**
 * Campus Connect — basic smoke tests (Node.js edition)
 *
 * These are lightweight integration tests that exercise the app through its
 * real HTTP API (using Node's built-in http module, no extra test framework
 * required) against an in-memory SQLite database. Run with: npm test
 */

process.env.DB_DIALECT = "sqlite";
process.env.DB_STORAGE = ":memory:";
process.env.DEMO_MODE = "true";
process.env.SESSION_SECRET = "test-secret";

const assert = require("assert");
const http = require("http");

const { sequelize, Category } = require("../models");
const app = require("../server");

let server;
let baseUrl;
let passed = 0;
let failed = 0;

function request(method, path, { body, cookie } = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request(
      `${baseUrl}${path}`,
      {
        method,
        headers: {
          "Content-Type": "application/json",
          ...(data ? { "Content-Length": Buffer.byteLength(data) } : {}),
          ...(cookie ? { Cookie: cookie } : {}),
        },
      },
      (res) => {
        let raw = "";
        res.on("data", (chunk) => (raw += chunk));
        res.on("end", () => {
          let json = null;
          try { json = JSON.parse(raw); } catch (e) { /* not JSON */ }
          const setCookie = res.headers["set-cookie"];
          resolve({ status: res.statusCode, body: json, raw, cookie: setCookie ? setCookie[0].split(";")[0] : cookie });
        });
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function test(name, fn) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err) {
    console.log(`  ✗ ${name}`);
    console.log(`    ${err.message}`);
    failed++;
  }
}

async function main() {
  await sequelize.sync({ force: true });
  await Category.create({ name: "Books" });

  server = app.listen(0);
  await new Promise((resolve) => server.on("listening", resolve));
  baseUrl = `http://localhost:${server.address().port}`;

  console.log("Running Campus Connect smoke tests...\n");

  let studentCookie = null;
  let otp = null;

  await test("rejects registration with a non-university email", async () => {
    const res = await request("POST", "/api/auth/register", {
      body: { name: "Bad", email: "bad@gmail.com", password: "Test@1234", confirm_password: "Test@1234", role: "student", department: "CS" },
    });
    assert.strictEqual(res.status, 400);
    assert.ok(res.body.fields.email);
  });

  await test("registers a new user with a valid university email", async () => {
    const res = await request("POST", "/api/auth/register", {
      body: { name: "Test User", email: "testuser@cuk.ac.in", password: "Test@1234", confirm_password: "Test@1234", role: "student", department: "CS" },
    });
    assert.strictEqual(res.status, 201);
    assert.strictEqual(res.body.user.is_verified, false);
    assert.ok(res.body.demo_otp);
    studentCookie = res.cookie;
    otp = res.body.demo_otp;
  });

  await test("rejects an incorrect verification code", async () => {
    const res = await request("POST", "/api/auth/verify", { body: { otp_code: "000000" }, cookie: studentCookie });
    assert.strictEqual(res.status, 400);
  });

  await test("verifies email with the correct demo OTP", async () => {
    const res = await request("POST", "/api/auth/verify", { body: { otp_code: otp }, cookie: studentCookie });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.user.is_verified, true);
  });

  await test("logs in with correct credentials", async () => {
    const res = await request("POST", "/api/auth/login", { body: { email: "testuser@cuk.ac.in", password: "Test@1234" } });
    assert.strictEqual(res.status, 200);
    studentCookie = res.cookie;
  });

  await test("rejects login with wrong password", async () => {
    const res = await request("POST", "/api/auth/login", { body: { email: "testuser@cuk.ac.in", password: "WrongPass1" } });
    assert.strictEqual(res.status, 401);
  });

  let listingId;
  await test("creates a listing when authenticated + verified", async () => {
    const category = await Category.findOne({ where: { name: "Books" } });
    const res = await request("POST", "/api/listings", {
      body: { title: "Test Book", description: "A book for testing", category_id: category.id, transaction_type: "sell", price: 100, condition: "Good" },
      cookie: studentCookie,
    });
    assert.strictEqual(res.status, 201);
    listingId = res.body.listing.id;
  });

  await test("retrieves the created listing from the database", async () => {
    const res = await request("GET", `/api/listings/${listingId}`);
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.listing.title, "Test Book");
  });

  await test("lists listings via search", async () => {
    const res = await request("GET", "/api/listings?q=Test");
    assert.strictEqual(res.status, 200);
    assert.ok(res.body.total >= 1);
  });

  await test("rejects unauthenticated listing update", async () => {
    const res = await request("PUT", `/api/listings/${listingId}`, { body: { title: "Hacked" } });
    assert.strictEqual(res.status, 401);
  });

  await test("adds a listing to the wishlist", async () => {
    const res = await request("POST", `/api/wishlist/${listingId}`, { cookie: studentCookie });
    assert.strictEqual(res.status, 201);
  });

  await test("wishlist reflects the added listing", async () => {
    const res = await request("GET", "/api/wishlist", { cookie: studentCookie });
    assert.strictEqual(res.status, 200);
    assert.ok(res.body.wishlist.some((l) => l.id === listingId));
  });

  let secondCookie;
  await test("creates and verifies a second user to test a transaction", async () => {
    const reg = await request("POST", "/api/auth/register", {
      body: { name: "Buyer User", email: "buyer@cuk.ac.in", password: "Test@1234", confirm_password: "Test@1234", role: "student", department: "CS" },
    });
    secondCookie = reg.cookie;
    await request("POST", "/api/auth/verify", { body: { otp_code: reg.body.demo_otp }, cookie: secondCookie });
  });

  let transactionId;
  await test("creates a purchase request as the second user", async () => {
    const res = await request("POST", "/api/transactions", { body: { listing_id: listingId, transaction_type: "sell" }, cookie: secondCookie });
    assert.strictEqual(res.status, 201);
    transactionId = res.body.transaction.id;
  });

  await test("rejects admin routes for a non-admin user", async () => {
    const res = await request("GET", "/api/admin/stats", { cookie: studentCookie });
    assert.strictEqual(res.status, 403);
  });

  await test("completes the transaction end-to-end and allows a review", async () => {
    await request("PUT", `/api/transactions/${transactionId}`, { body: { action: "accept" }, cookie: studentCookie });
    await request("PUT", `/api/transactions/${transactionId}`, { body: { action: "confirm" }, cookie: studentCookie });
    const final = await request("PUT", `/api/transactions/${transactionId}`, { body: { action: "confirm" }, cookie: secondCookie });
    assert.strictEqual(final.body.transaction.status, "completed");

    const review = await request("POST", "/api/reviews", { body: { transaction_id: transactionId, rating: 5, comment: "Nice!" }, cookie: secondCookie });
    assert.strictEqual(review.status, 201);

    const dup = await request("POST", "/api/reviews", { body: { transaction_id: transactionId, rating: 4 }, cookie: secondCookie });
    assert.strictEqual(dup.status, 400);
  });

  console.log(`\n${passed} passed, ${failed} failed\n`);
  server.close();
  await sequelize.close();
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test run crashed:", err);
  process.exit(1);
});
