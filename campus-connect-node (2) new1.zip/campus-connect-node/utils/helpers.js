const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const config = require("../config");

function isUniversityEmail(email) {
  return (email || "").toLowerCase().trim().endsWith("@" + config.universityEmailDomain);
}

function generateOtp() {
  if (config.demoMode) return config.demoOtpCode;
  return String(crypto.randomInt(100000, 999999));
}

function otpExpiry() {
  return new Date(Date.now() + 15 * 60 * 1000);
}

// --- Multer setup for image uploads ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadFolder),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(".", "");
    const safeExt = config.allowedImageExt.has(ext) ? ext : "jpg";
    cb(null, `${crypto.randomBytes(16).toString("hex")}.${safeExt}`);
  },
});

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase().replace(".", "");
  if (!config.allowedImageExt.has(ext)) {
    return cb(new Error("Unsupported file type. Use JPG, JPEG, PNG, or WebP."));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: config.maxUploadBytes, files: 6 },
});

module.exports = { isUniversityEmail, generateOtp, otpExpiry, upload };
